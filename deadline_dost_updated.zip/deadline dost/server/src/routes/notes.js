import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { noteUpdateSchema } from '../validators/schemas.js';
import { getNote, saveNote } from '../controllers/noteController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getNote);
router.put('/', validate(noteUpdateSchema), saveNote);

export default router;
