import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { getMe } from '../controllers/authController.js';

const router = Router();

// GET /api/auth/me - returns authenticated user details and profile
router.get('/me', requireAuth, getMe);

export default router;
