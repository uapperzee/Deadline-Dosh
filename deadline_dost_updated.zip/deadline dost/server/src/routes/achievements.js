import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { getAchievements } from '../controllers/achievementController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getAchievements);

export default router;
