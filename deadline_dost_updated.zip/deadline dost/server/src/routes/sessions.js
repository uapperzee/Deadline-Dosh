import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { sessionCreateSchema } from '../validators/schemas.js';
import {
  getSessions,
  createSession,
  deleteSession
} from '../controllers/sessionController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getSessions);
router.post('/', validate(sessionCreateSchema), createSession);
router.delete('/:id', deleteSession);

export default router;
