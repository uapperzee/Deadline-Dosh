import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { subjectCreateSchema, subjectUpdateSchema } from '../validators/schemas.js';
import {
  getSubjects,
  createSubject,
  updateSubject,
  toggleArchiveSubject,
  deleteSubject
} from '../controllers/subjectController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getSubjects);
router.post('/', validate(subjectCreateSchema), createSubject);
router.patch('/:id', validate(subjectUpdateSchema), updateSubject);
router.patch('/:id/archive', toggleArchiveSubject);
router.delete('/:id', deleteSubject);

export default router;
