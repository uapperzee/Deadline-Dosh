import { Router } from 'express';
import { config } from '../config/env.js';

const router = Router();

router.get('/', (req, res) => {
  res.json({
    status: 'healthy',
    platform: 'Deadline Dost API',
    version: '1.0.0',
    uptime: Math.round(process.uptime()),
    timestamp: new Date().toISOString(),
    environment: config.nodeEnv,
    services: {
      supabase_configured: !!config.supabase.url,
      ai_configured: !!(config.ai.apiKey && config.ai.apiKey !== 'your-gemini-or-openai-api-key-here')
    }
  });
});

export default router;
