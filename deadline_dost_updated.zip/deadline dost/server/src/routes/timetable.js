import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { timetableBulkSchema } from '../validators/schemas.js';
import {
  getTimetable,
  updateSlot,
  bulkUpdateTimetable,
  clearTimetable
} from '../controllers/timetableController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getTimetable);
router.post('/slot', updateSlot);
router.put('/bulk', validate(timetableBulkSchema), bulkUpdateTimetable);
router.delete('/', clearTimetable);

export default router;
