import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { exportUserData } from '../controllers/exportController.js';

const router = Router();

router.use(requireAuth);

router.get('/', exportUserData);

export default router;
