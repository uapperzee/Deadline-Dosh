import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { profileUpdateSchema, preferencesUpdateSchema } from '../validators/schemas.js';
import {
  getProfile,
  updateProfile,
  getPreferences,
  updatePreferences,
  deleteAccount
} from '../controllers/profileController.js';

const router = Router();

// Protect all profile routes with authenticated session
router.use(requireAuth);

router.get('/', getProfile);
router.patch('/', validate(profileUpdateSchema), updateProfile);

router.get('/preferences', getPreferences);
router.put('/preferences', validate(preferencesUpdateSchema), updatePreferences);

router.post('/delete-account', deleteAccount);

export default router;
