import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { taskCreateSchema, taskUpdateSchema } from '../validators/schemas.js';
import {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  toggleTask,
  deleteTask
} from '../controllers/taskController.js';

const router = Router();

router.use(requireAuth);

router.get('/', getTasks);
router.get('/:id', getTaskById);
router.post('/', validate(taskCreateSchema), createTask);
router.patch('/:id', validate(taskUpdateSchema), updateTask);
router.patch('/:id/toggle', toggleTask);
router.delete('/:id', deleteTask);

export default router;
