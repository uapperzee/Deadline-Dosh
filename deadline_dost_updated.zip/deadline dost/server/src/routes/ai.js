import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { validate } from '../middleware/validator.js';
import { sensitiveLimiter } from '../middleware/rateLimiter.js';
import { aiPromptSchema } from '../validators/schemas.js';
import {
  chat,
  getChatHistory,
  clearChatHistory,
  generateStudyPlan
} from '../controllers/aiController.js';

const router = Router();

router.use(requireAuth);

router.post('/chat', sensitiveLimiter, validate(aiPromptSchema), chat);
router.get('/history', getChatHistory);
router.delete('/history', clearChatHistory);
router.post('/study-plan', sensitiveLimiter, generateStudyPlan);

export default router;
