import { createClient } from '@supabase/supabase-js';
import { config } from '../config/env.js';
import { getScopedClient } from '../config/supabase.js';

export const requireAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required. Missing or malformed Bearer token.'
      });
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Invalid token.'
      });
    }

    if (!config.supabase.url || (!config.supabase.anonKey && !config.supabase.serviceRoleKey)) {
      return res.status(500).json({
        success: false,
        error: 'Authentication provider is not configured on the server. Please set SUPABASE_URL and SUPABASE_ANON_KEY.'
      });
    }

    // Verify token with Supabase Auth
    const verifier = createClient(config.supabase.url, config.supabase.anonKey || config.supabase.serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false }
    });

    const { data: { user }, error } = await verifier.auth.getUser(token);

    if (error || !user) {
      return res.status(401).json({
        success: false,
        error: 'Session expired or invalid token. Please sign in again.'
      });
    }

    // Securely attach verified user identity and scoped DB client
    req.user = user;
    req.userId = user.id;
    req.token = token;
    req.db = getScopedClient(token);

    next();
  } catch (err) {
    console.error('[Auth Middleware] Verification error:', err.message);
    return res.status(401).json({
      success: false,
      error: 'Authentication verification failed.'
    });
  }
};
