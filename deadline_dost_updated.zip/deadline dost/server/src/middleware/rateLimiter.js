import rateLimit from 'express-rate-limit';

// Standard rate limiter for general API endpoints
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300, // Limit each IP to 300 requests per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many requests from this IP, please try again after 15 minutes.'
  }
});

// Stricter rate limiter for resource-intensive or sensitive endpoints (e.g. AI queries, password resets)
export const sensitiveLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30, // Limit to 30 requests per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many requests. Please wait a few minutes before trying again.'
  }
});
