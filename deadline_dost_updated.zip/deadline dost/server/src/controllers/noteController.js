export const getNote = async (req, res, next) => {
  try {
    const { data: note, error } = await req.db
      .from('notes')
      .select('*')
      .eq('user_id', req.userId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (!note) {
      // Create default note
      const { data: newNote, error: createError } = await req.db
        .from('notes')
        .insert({
          user_id: req.userId,
          title: 'Quick note',
          body: ''
        })
        .select()
        .single();

      if (createError) throw createError;
      return res.json({ success: true, data: newNote });
    }

    res.json({ success: true, data: note });
  } catch (err) {
    next(err);
  }
};

export const saveNote = async (req, res, next) => {
  try {
    const { title = 'Quick note', body = '' } = req.body;

    // Check existing note
    const { data: existing } = await req.db
      .from('notes')
      .select('id')
      .eq('user_id', req.userId)
      .limit(1)
      .maybeSingle();

    let result;
    if (existing) {
      const { data, error } = await req.db
        .from('notes')
        .update({ title, body })
        .eq('id', existing.id)
        .eq('user_id', req.userId)
        .select()
        .single();

      if (error) throw error;
      result = data;
    } else {
      const { data, error } = await req.db
        .from('notes')
        .insert({ user_id: req.userId, title, body })
        .select()
        .single();

      if (error) throw error;
      result = data;
    }

    res.json({
      success: true,
      data: result
    });
  } catch (err) {
    next(err);
  }
};
