export const getSubjects = async (req, res, next) => {
  try {
    const { data: subjects, error: subjError } = await req.db
      .from('subjects')
      .select('*')
      .eq('user_id', req.userId)
      .order('name', { ascending: true });

    if (subjError) throw subjError;

    // Fetch tasks count & study hours per subject
    const { data: tasks, error: taskError } = await req.db
      .from('tasks')
      .select('id, subject_id, status, category, due_date')
      .eq('user_id', req.userId);

    if (taskError) throw taskError;

    const { data: sessions, error: sessError } = await req.db
      .from('study_sessions')
      .select('duration_minutes, task_id')
      .eq('user_id', req.userId);

    if (sessError) throw sessError;

    const allTasks = tasks || [];
    const allSessions = sessions || [];

    const enriched = (subjects || []).map(s => {
      const subjTasks = allTasks.filter(t => t.subject_id === s.id);
      const completed = subjTasks.filter(t => t.status === 'Completed').length;
      const upcomingExams = subjTasks.filter(t => t.category === 'Exam' && t.status !== 'Completed' && new Date(t.due_date) > new Date()).length;
      
      const subjTaskIds = new Set(subjTasks.map(t => t.id));
      const studyMinutes = allSessions
        .filter(sess => subjTaskIds.has(sess.task_id))
        .reduce((sum, sess) => sum + (sess.duration_minutes || 0), 0);

      return {
        ...s,
        total_tasks: subjTasks.length,
        completed_tasks: completed,
        completion_percent: subjTasks.length ? Math.round((completed / subjTasks.length) * 100) : 0,
        upcoming_exams: upcomingExams,
        study_hours: parseFloat((studyMinutes / 60).toFixed(1))
      };
    });

    res.json({
      success: true,
      data: enriched
    });
  } catch (err) {
    next(err);
  }
};

export const createSubject = async (req, res, next) => {
  try {
    const payload = {
      ...req.body,
      user_id: req.userId
    };

    const { data: created, error } = await req.db
      .from('subjects')
      .insert(payload)
      .select()
      .single();

    if (error) throw error;

    res.status(201).json({
      success: true,
      message: 'Subject added successfully.',
      data: created
    });
  } catch (err) {
    next(err);
  }
};

export const updateSubject = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { data: updated, error } = await req.db
      .from('subjects')
      .update(req.body)
      .eq('id', id)
      .eq('user_id', req.userId)
      .select()
      .single();

    if (error) throw error;

    res.json({
      success: true,
      message: 'Subject updated successfully.',
      data: updated
    });
  } catch (err) {
    next(err);
  }
};

export const toggleArchiveSubject = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { data: existing, error: findError } = await req.db
      .from('subjects')
      .select('id, is_archived')
      .eq('id', id)
      .eq('user_id', req.userId)
      .single();

    if (findError || !existing) {
      return res.status(404).json({ success: false, error: 'Subject not found.' });
    }

    const { data: updated, error: updateError } = await req.db
      .from('subjects')
      .update({ is_archived: !existing.is_archived })
      .eq('id', id)
      .eq('user_id', req.userId)
      .select()
      .single();

    if (updateError) throw updateError;

    res.json({
      success: true,
      message: updated.is_archived ? 'Subject archived.' : 'Subject restored.',
      data: updated
    });
  } catch (err) {
    next(err);
  }
};

export const deleteSubject = async (req, res, next) => {
  try {
    const { id } = req.params;

    // Check if tasks exist for this subject
    const { count, error: countError } = await req.db
      .from('tasks')
      .select('id', { count: 'exact', head: true })
      .eq('subject_id', id)
      .eq('user_id', req.userId);

    if (countError) throw countError;

    if (count > 0) {
      return res.status(400).json({
        success: false,
        error: `Cannot delete subject because it is linked to ${count} task(s). Archive it instead to preserve your history.`
      });
    }

    const { error: delError } = await req.db
      .from('subjects')
      .delete()
      .eq('id', id)
      .eq('user_id', req.userId);

    if (delError) throw delError;

    res.json({
      success: true,
      message: 'Subject deleted successfully.'
    });
  } catch (err) {
    next(err);
  }
};
