import { calculateStreaks } from '../services/statsService.js';

export const getAnalytics = async (req, res, next) => {
  try {
    const rangeDays = parseInt(req.query.days || '7', 10);
    const days = rangeDays === 14 ? 14 : 7;

    // Fetch user's tasks
    const { data: tasks, error: taskError } = await req.db
      .from('tasks')
      .select('id, title, category, status, due_date, estimated_minutes, done_at, subject_id, subject:subjects(id, name)')
      .eq('user_id', req.userId);

    if (taskError) throw taskError;

    // Fetch user's study sessions
    const { data: sessions, error: sessError } = await req.db
      .from('study_sessions')
      .select('id, duration_minutes, task_id, created_at, started_at, task:tasks(id, title, subject_id, subject:subjects(name))')
      .eq('user_id', req.userId);

    if (sessError) throw sessError;

    // Fetch user profile for timezone
    const { data: profile } = await req.db
      .from('profiles')
      .select('timezone')
      .eq('id', req.userId)
      .maybeSingle();

    const tz = profile?.timezone || 'UTC';
    const now = new Date();

    const toDateKey = (dateObj) => {
      return dateObj.toLocaleDateString('en-CA', { timeZone: tz });
    };

    // Build day buckets for the past `days` days
    const dayBuckets = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = toDateKey(d);
      const shortDay = d.toLocaleDateString('en-US', { weekday: 'short', timeZone: tz }).slice(0, 2);
      const dayNum = d.getDate();
      dayBuckets.push({
        dateKey: key,
        label: days === 14 ? String(dayNum) : shortDay,
        fullDate: key,
        studyMinutes: 0,
        tasksCompleted: 0
      });
    }

    const bucketMap = new Map();
    dayBuckets.forEach(b => bucketMap.set(b.dateKey, b));

    const allSessions = sessions || [];
    const allTasks = tasks || [];

    // Aggregate sessions into day buckets
    allSessions.forEach(s => {
      const sessionDate = new Date(s.created_at || s.started_at);
      const k = toDateKey(sessionDate);
      if (bucketMap.has(k)) {
        bucketMap.get(k).studyMinutes += (s.duration_minutes || 0);
      }
    });

    // Aggregate completed tasks into day buckets
    allTasks.forEach(t => {
      if (t.done_at) {
        const k = toDateKey(new Date(t.done_at));
        if (bucketMap.has(k)) {
          bucketMap.get(k).tasksCompleted += 1;
        }
      }
    });

    const dailyMinutes = dayBuckets.map(b => b.studyMinutes);
    const dailyCompleted = dayBuckets.map(b => b.tasksCompleted);
    const labels = dayBuckets.map(b => b.label);

    const totalMinutesInRange = dailyMinutes.reduce((a, b) => a + b, 0);
    const totalStudyHoursInRange = parseFloat((totalMinutesInRange / 60).toFixed(1));
    const totalCompletedInRange = dailyCompleted.reduce((a, b) => a + b, 0);

    // On-time completion rate: completed tasks finished on or before due_date
    const completedWithDates = allTasks.filter(t => t.status === 'Completed' && t.done_at);
    const onTimeTasks = completedWithDates.filter(t => new Date(t.done_at) <= new Date(t.due_date));
    const onTimeRate = completedWithDates.length ? Math.round((onTimeTasks.length / completedWithDates.length) * 100) : 0;

    const overdueNow = allTasks.filter(t => t.status !== 'Completed' && new Date(t.due_date) < now).length;

    // Day streak
    const streakInfo = calculateStreaks(allSessions, allTasks.filter(t => t.status === 'Completed'), tz);

    // Focus sessions count in range
    const sessionsInRange = allSessions.filter(s => {
      const k = toDateKey(new Date(s.created_at || s.started_at));
      return bucketMap.has(k);
    });

    // Study breakdown by subject
    const subjectMinutesMap = {};
    sessionsInRange.forEach(s => {
      const subjName = s.task?.subject?.name || 'Unassigned / General';
      subjectMinutesMap[subjName] = (subjectMinutesMap[subjName] || 0) + (s.duration_minutes || 0);
    });

    // Planned vs actual study minutes
    const plannedStudyMinutes = allTasks
      .filter(t => t.category === 'Study' && bucketMap.has(toDateKey(new Date(t.due_date))))
      .reduce((sum, t) => sum + (t.estimated_minutes || 60), 0);

    res.json({
      success: true,
      data: {
        range_days: days,
        labels,
        daily_minutes: dailyMinutes,
        daily_completed: dailyCompleted,
        total_study_hours: totalStudyHoursInRange,
        total_study_minutes: totalMinutesInRange,
        tasks_completed: totalCompletedInRange,
        on_time_rate: onTimeRate,
        overdue_count: overdueNow,
        current_streak: streakInfo.currentStreak,
        longest_streak: streakInfo.longestStreak,
        focus_sessions_count: sessionsInRange.length,
        subject_breakdown: subjectMinutesMap,
        planned_minutes: plannedStudyMinutes,
        actual_minutes: totalMinutesInRange
      }
    });
  } catch (err) {
    next(err);
  }
};
