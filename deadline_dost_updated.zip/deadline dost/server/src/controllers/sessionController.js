export const getSessions = async (req, res, next) => {
  try {
    const { limit = 50 } = req.query;

    const { data: sessions, error } = await req.db
      .from('study_sessions')
      .select('*, task:tasks (id, title, category, subject_id)')
      .eq('user_id', req.userId)
      .order('created_at', { ascending: false })
      .limit(parseInt(limit, 10));

    if (error) throw error;

    res.json({
      success: true,
      data: sessions || []
    });
  } catch (err) {
    next(err);
  }
};

export const createSession = async (req, res, next) => {
  try {
    const payload = {
      ...req.body,
      user_id: req.userId,
      started_at: req.body.started_at || new Date().toISOString()
    };

    const { data: created, error } = await req.db
      .from('study_sessions')
      .insert(payload)
      .select('*, task:tasks (id, title, category)')
      .single();

    if (error) throw error;

    res.status(201).json({
      success: true,
      message: 'Study session recorded successfully.',
      data: created
    });
  } catch (err) {
    next(err);
  }
};

export const deleteSession = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { error } = await req.db
      .from('study_sessions')
      .delete()
      .eq('id', id)
      .eq('user_id', req.userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Study session removed.'
    });
  } catch (err) {
    next(err);
  }
};
