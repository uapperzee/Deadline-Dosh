export const exportUserData = async (req, res, next) => {
  try {
    // 1. Profile
    const { data: profile } = await req.db
      .from('profiles')
      .select('*')
      .eq('id', req.userId)
      .maybeSingle();

    // 2. Preferences
    const { data: preferences } = await req.db
      .from('user_preferences')
      .select('*')
      .eq('user_id', req.userId)
      .maybeSingle();

    // 3. Subjects
    const { data: subjects } = await req.db
      .from('subjects')
      .select('*')
      .eq('user_id', req.userId);

    // 4. Tasks with subtasks
    const { data: tasks } = await req.db
      .from('tasks')
      .select('*, subtasks(*)')
      .eq('user_id', req.userId);

    // 5. Study sessions
    const { data: sessions } = await req.db
      .from('study_sessions')
      .select('*')
      .eq('user_id', req.userId);

    // 6. Timetable
    const { data: timetable } = await req.db
      .from('timetable_entries')
      .select('*')
      .eq('user_id', req.userId);

    // 7. Notes
    const { data: notes } = await req.db
      .from('notes')
      .select('*')
      .eq('user_id', req.userId);

    // 8. Achievements
    const { data: achievements } = await req.db
      .from('user_achievements')
      .select('*')
      .eq('user_id', req.userId);

    const exportPayload = {
      export_version: '1.0',
      exported_at: new Date().toISOString(),
      user: {
        id: req.user.id,
        email: req.user.email,
        profile,
        preferences
      },
      data: {
        subjects: subjects || [],
        tasks: tasks || [],
        study_sessions: sessions || [],
        timetable: timetable || [],
        notes: notes || [],
        achievements: achievements || []
      }
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="deadline-dost-export-${new Date().toISOString().split('T')[0]}.json"`);
    res.json(exportPayload);
  } catch (err) {
    next(err);
  }
};
