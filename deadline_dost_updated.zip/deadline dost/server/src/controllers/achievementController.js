import { BADGE_DEFINITIONS, calculateStreaks, calculateXP } from '../services/statsService.js';

export const getAchievements = async (req, res, next) => {
  try {
    // 1. Fetch user's tasks
    const { data: tasks } = await req.db
      .from('tasks')
      .select('id, status, done_at')
      .eq('user_id', req.userId);

    // 2. Fetch user's sessions
    const { data: sessions } = await req.db
      .from('study_sessions')
      .select('id, duration_minutes, created_at, started_at')
      .eq('user_id', req.userId);

    // 3. Fetch subjects count
    const { count: subjectsCount } = await req.db
      .from('subjects')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', req.userId);

    // 4. Fetch timetable slots count
    const { data: ttEntries } = await req.db
      .from('timetable_entries')
      .select('content')
      .eq('user_id', req.userId);

    // 5. Fetch existing unlocked achievements
    const { data: unlockedRows } = await req.db
      .from('user_achievements')
      .select('badge_key, unlocked_at')
      .eq('user_id', req.userId);

    const allTasks = tasks || [];
    const allSessions = sessions || [];
    const completedTasks = allTasks.filter(t => t.status === 'Completed');
    const totalFocusMinutes = allSessions.reduce((acc, s) => acc + (s.duration_minutes || 0), 0);
    const focusHours = Math.floor(totalFocusMinutes / 60);
    const streakInfo = calculateStreaks(allSessions, completedTasks);
    const timetableFilledCount = (ttEntries || []).filter(e => e.content && e.content.trim().length > 0).length;

    const unlockedMap = {};
    (unlockedRows || []).forEach(r => {
      unlockedMap[r.badge_key] = r.unlocked_at;
    });

    // Check which badges qualify
    const newUnlocks = [];

    const badges = BADGE_DEFINITIONS.map(def => {
      let currentVal = 0;
      if (def.type === 'tasks') currentVal = completedTasks.length;
      else if (def.type === 'streak') currentVal = streakInfo.currentStreak;
      else if (def.type === 'sessions') currentVal = allSessions.length;
      else if (def.type === 'focus_hours') currentVal = focusHours;
      else if (def.type === 'subjects') currentVal = subjectsCount || 0;
      else if (def.type === 'timetable') currentVal = timetableFilledCount;

      const isEarned = !!unlockedMap[def.key] || currentVal >= def.goal;

      if (!unlockedMap[def.key] && currentVal >= def.goal) {
        newUnlocks.push({
          user_id: req.userId,
          badge_key: def.key,
          unlocked_at: new Date().toISOString()
        });
      }

      return {
        key: def.key,
        title: def.title,
        description: def.description,
        goal: def.goal,
        current: currentVal,
        percent: Math.min(100, Math.round((currentVal / def.goal) * 100)),
        is_earned: isEarned,
        unlocked_at: unlockedMap[def.key] || (currentVal >= def.goal ? new Date().toISOString() : null)
      };
    });

    // If new badges were earned, persist them to database
    if (newUnlocks.length > 0) {
      await req.db
        .from('user_achievements')
        .insert(newUnlocks)
        .select();
    }

    const earnedCount = badges.filter(b => b.is_earned).length;
    const xpInfo = calculateXP({
      completedTasksCount: completedTasks.length,
      focusMinutes: totalFocusMinutes,
      subjectsCount: subjectsCount || 0,
      achievementsCount: earnedCount
    });

    res.json({
      success: true,
      data: {
        badges,
        earned_count: earnedCount,
        total_badges: badges.length,
        completion_percent: Math.round((earnedCount / badges.length) * 100),
        xp: xpInfo
      }
    });
  } catch (err) {
    next(err);
  }
};
