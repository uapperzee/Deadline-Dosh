export const getTasks = async (req, res, next) => {
  try {
    const { category, priority, status, subject_id, search, sort = 'due' } = req.query;

    let query = req.db
      .from('tasks')
      .select(`
        *,
        subject:subjects (id, name, code, color),
        subtasks (id, title, is_completed, position)
      `)
      .eq('user_id', req.userId);

    if (category) query = query.eq('category', category);
    if (priority) query = query.eq('priority', priority);
    if (status) query = query.eq('status', status);
    if (subject_id) query = query.eq('subject_id', subject_id);
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%,notes.ilike.%${search}%`);
    }

    if (sort === 'pri') {
      // In JS sort below, or default order
      query = query.order('due_date', { ascending: true });
    } else if (sort === 'new') {
      query = query.order('created_at', { ascending: false });
    } else if (sort === 'title') {
      query = query.order('title', { ascending: true });
    } else {
      query = query.order('due_date', { ascending: true });
    }

    const { data: tasks, error } = await query;
    if (error) throw error;

    // Order subtasks by position
    const formatted = (tasks || []).map(t => ({
      ...t,
      subtasks: (t.subtasks || []).sort((a, b) => a.position - b.position)
    }));

    res.json({
      success: true,
      data: formatted
    });
  } catch (err) {
    next(err);
  }
};

export const getTaskById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { data: task, error } = await req.db
      .from('tasks')
      .select(`
        *,
        subject:subjects (id, name, code, color),
        subtasks (id, title, is_completed, position)
      `)
      .eq('id', id)
      .eq('user_id', req.userId)
      .single();

    if (error || !task) {
      return res.status(404).json({ success: false, error: 'Task not found.' });
    }

    task.subtasks = (task.subtasks || []).sort((a, b) => a.position - b.position);

    res.json({ success: true, data: task });
  } catch (err) {
    next(err);
  }
};

export const createTask = async (req, res, next) => {
  try {
    const { subtasks = [], ...taskData } = req.body;

    const insertPayload = {
      ...taskData,
      user_id: req.userId,
      done_at: taskData.status === 'Completed' ? new Date().toISOString() : null
    };

    const { data: createdTask, error: taskError } = await req.db
      .from('tasks')
      .insert(insertPayload)
      .select('*, subject:subjects (id, name, code, color)')
      .single();

    if (taskError) throw taskError;

    let createdSubtasks = [];
    if (subtasks.length > 0) {
      const subtaskPayload = subtasks.map((st, idx) => ({
        task_id: createdTask.id,
        user_id: req.userId,
        title: st.title,
        is_completed: !!st.is_completed,
        position: st.position ?? idx
      }));

      const { data: subData, error: subError } = await req.db
        .from('subtasks')
        .insert(subtaskPayload)
        .select('id, title, is_completed, position');

      if (subError) throw subError;
      createdSubtasks = subData || [];
    }

    res.status(201).json({
      success: true,
      message: 'Task created successfully.',
      data: {
        ...createdTask,
        subtasks: createdSubtasks
      }
    });
  } catch (err) {
    next(err);
  }
};

export const updateTask = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { subtasks, ...updates } = req.body;

    // Check existing task for status transition
    const { data: existing, error: findError } = await req.db
      .from('tasks')
      .select('status, done_at')
      .eq('id', id)
      .eq('user_id', req.userId)
      .single();

    if (findError || !existing) {
      return res.status(404).json({ success: false, error: 'Task not found.' });
    }

    if (updates.status) {
      if (updates.status === 'Completed' && existing.status !== 'Completed') {
        updates.done_at = new Date().toISOString();
      } else if (updates.status !== 'Completed') {
        updates.done_at = null;
      }
    }

    const { data: updatedTask, error: updateError } = await req.db
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .eq('user_id', req.userId)
      .select('*, subject:subjects (id, name, code, color)')
      .single();

    if (updateError) throw updateError;

    // Handle subtasks if provided
    let finalSubtasks = [];
    if (Array.isArray(subtasks)) {
      // Delete existing subtasks for this task
      await req.db
        .from('subtasks')
        .delete()
        .eq('task_id', id)
        .eq('user_id', req.userId);

      if (subtasks.length > 0) {
        const subtaskPayload = subtasks.map((st, idx) => ({
          task_id: id,
          user_id: req.userId,
          title: st.title,
          is_completed: !!st.is_completed,
          position: st.position ?? idx
        }));

        const { data: newSubs, error: subError } = await req.db
          .from('subtasks')
          .insert(subtaskPayload)
          .select('id, title, is_completed, position');

        if (subError) throw subError;
        finalSubtasks = newSubs || [];
      }
    } else {
      const { data: existingSubs } = await req.db
        .from('subtasks')
        .select('id, title, is_completed, position')
        .eq('task_id', id)
        .order('position', { ascending: true });
      finalSubtasks = existingSubs || [];
    }

    res.json({
      success: true,
      message: 'Task updated successfully.',
      data: {
        ...updatedTask,
        subtasks: finalSubtasks
      }
    });
  } catch (err) {
    next(err);
  }
};

export const toggleTask = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { data: task, error: findError } = await req.db
      .from('tasks')
      .select('id, status')
      .eq('id', id)
      .eq('user_id', req.userId)
      .single();

    if (findError || !task) {
      return res.status(404).json({ success: false, error: 'Task not found.' });
    }

    const isCompleted = task.status === 'Completed';
    const newStatus = isCompleted ? 'To Do' : 'Completed';
    const done_at = isCompleted ? null : new Date().toISOString();

    const { data: updated, error: updateError } = await req.db
      .from('tasks')
      .update({ status: newStatus, done_at })
      .eq('id', id)
      .eq('user_id', req.userId)
      .select('*, subject:subjects (id, name, code, color), subtasks (*)')
      .single();

    if (updateError) throw updateError;

    res.json({
      success: true,
      message: isCompleted ? 'Task reopened.' : 'Task completed!',
      data: updated
    });
  } catch (err) {
    next(err);
  }
};

export const deleteTask = async (req, res, next) => {
  try {
    const { id } = req.params;

    const { error } = await req.db
      .from('tasks')
      .delete()
      .eq('id', id)
      .eq('user_id', req.userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Task deleted successfully.'
    });
  } catch (err) {
    next(err);
  }
};
