import { supabaseAdmin } from '../config/supabase.js';

export const getMe = async (req, res, next) => {
  try {
    const { data: profile, error } = await req.db
      .from('profiles')
      .select('*')
      .eq('id', req.userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      throw error;
    }

    res.json({
      success: true,
      data: {
        id: req.user.id,
        email: req.user.email,
        email_confirmed_at: req.user.email_confirmed_at,
        created_at: req.user.created_at,
        profile: profile || {
          id: req.user.id,
          email: req.user.email,
          full_name: req.user.user_metadata?.full_name || '',
          username: '',
          avatar_url: req.user.user_metadata?.avatar_url || ''
        }
      }
    });
  } catch (err) {
    next(err);
  }
};
