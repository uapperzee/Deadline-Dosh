import { AIService } from '../services/aiService.js';
import { calculateStreaks } from '../services/statsService.js';

export const chat = async (req, res, next) => {
  try {
    const { prompt } = req.body;

    // 1. Fetch user academic context
    const { data: profile } = await req.db
      .from('profiles')
      .select('full_name, course, semester, study_goal, timezone')
      .eq('id', req.userId)
      .maybeSingle();

    const { data: tasks } = await req.db
      .from('tasks')
      .select('id, title, category, priority, status, due_date, subject:subjects(name)')
      .eq('user_id', req.userId);

    const { data: subjects } = await req.db
      .from('subjects')
      .select('id, name, code')
      .eq('user_id', req.userId)
      .eq('is_archived', false);

    const { data: sessions } = await req.db
      .from('study_sessions')
      .select('duration_minutes, created_at, started_at')
      .eq('user_id', req.userId);

    const { data: prefs } = await req.db
      .from('user_preferences')
      .select('weekly_target_hours')
      .eq('user_id', req.userId)
      .maybeSingle();

    const { data: recentHistory } = await req.db
      .from('ai_chat_history')
      .select('role, content')
      .eq('user_id', req.userId)
      .order('created_at', { ascending: false })
      .limit(8);

    const now = new Date();
    const allTasks = tasks || [];
    const activeTasks = allTasks.filter(t => t.status !== 'Completed').map(t => ({
      ...t,
      subject_name: t.subject?.name
    }));
    const overdueTasks = activeTasks.filter(t => new Date(t.due_date) < now);
    const upcomingExams = activeTasks.filter(t => t.category === 'Exam');

    const totalMinutes = (sessions || []).reduce((acc, s) => acc + (s.duration_minutes || 0), 0);
    const streakInfo = calculateStreaks(sessions || [], allTasks.filter(t => t.status === 'Completed'), profile?.timezone || 'UTC');

    const studentContext = {
      name: profile?.full_name || req.user.user_metadata?.full_name || 'Student',
      course: profile?.course || '',
      semester: profile?.semester || '',
      studyGoal: profile?.study_goal || '',
      activeTasks,
      overdueTasks,
      upcomingExams,
      subjects: subjects || [],
      streak: streakInfo.currentStreak,
      totalStudyHours: parseFloat((totalMinutes / 60).toFixed(1)),
      weeklyTarget: prefs?.weekly_target_hours || 10
    };

    // 2. Generate response
    const assistantReply = await AIService.generateChatResponse({
      prompt,
      studentContext,
      chatHistory: (recentHistory || []).reverse()
    });

    // 3. Persist user prompt and assistant response to database
    await req.db
      .from('ai_chat_history')
      .insert([
        { user_id: req.userId, role: 'user', content: prompt },
        { user_id: req.userId, role: 'assistant', content: assistantReply }
      ]);

    res.json({
      success: true,
      data: {
        role: 'assistant',
        content: assistantReply
      }
    });
  } catch (err) {
    next(err);
  }
};

export const getChatHistory = async (req, res, next) => {
  try {
    const { data: history, error } = await req.db
      .from('ai_chat_history')
      .select('id, role, content, created_at')
      .eq('user_id', req.userId)
      .order('created_at', { ascending: true })
      .limit(50);

    if (error) throw error;

    res.json({
      success: true,
      data: history || []
    });
  } catch (err) {
    next(err);
  }
};

export const clearChatHistory = async (req, res, next) => {
  try {
    const { error } = await req.db
      .from('ai_chat_history')
      .delete()
      .eq('user_id', req.userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Chat history cleared successfully.'
    });
  } catch (err) {
    next(err);
  }
};

export const generateStudyPlan = async (req, res, next) => {
  try {
    const { subject_id, exam_date, daily_hours } = req.body;

    if (!subject_id || !exam_date || !daily_hours) {
      return res.status(400).json({
        success: false,
        error: 'subject_id, exam_date, and daily_hours are required.'
      });
    }

    const examDate = new Date(exam_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const diffDays = Math.round((examDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays <= 0) {
      return res.status(400).json({
        success: false,
        error: 'Exam date must be at least 1 day in the future.'
      });
    }

    // Fetch subject details and open tasks
    const { data: subject } = await req.db
      .from('subjects')
      .select('name, code')
      .eq('id', subject_id)
      .eq('user_id', req.userId)
      .single();

    const { data: subjectTasks } = await req.db
      .from('tasks')
      .select('title, priority')
      .eq('subject_id', subject_id)
      .eq('user_id', req.userId)
      .neq('status', 'Completed')
      .neq('category', 'Exam');

    const topics = (subjectTasks || []).map(t => t.title);
    if (!topics.length) {
      topics.push(`Unit 1 Foundation in ${subject?.name || 'Subject'}`);
      topics.push(`Unit 2 Core Concepts & Problem Solving`);
      topics.push(`Unit 3 Advanced Topics & Theorems`);
      topics.push(`Mock Exam & Timed Practice`);
    }

    const planRows = [];
    let topicIndex = 0;
    const hours = Math.min(12, Math.max(0.5, parseFloat(daily_hours)));
    const maxDays = Math.min(Math.max(diffDays - 1, 1), 21);

    for (let i = 1; i <= maxDays; i++) {
      const scheduleDate = new Date(today);
      scheduleDate.setDate(scheduleDate.getDate() + i);
      const dateStr = scheduleDate.toISOString().split('T')[0];

      let remainingMinutes = hours * 60;
      while (remainingMinutes > 0) {
        const block = Math.min(50, remainingMinutes);
        const topic = topics[topicIndex++ % topics.length];
        planRows.push({
          date: dateStr,
          topic: `Study & Revise: ${topic}`,
          minutes: block
        });
        remainingMinutes -= block;
      }
    }

    res.json({
      success: true,
      data: {
        subject_id,
        subject_name: subject?.name || 'Subject',
        exam_date,
        daily_hours: hours,
        total_blocks: planRows.length,
        schedule: planRows
      }
    });
  } catch (err) {
    next(err);
  }
};
