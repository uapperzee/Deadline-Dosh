export const migrateLocalData = async (req, res, next) => {
  try {
    const { tasks = [], subjects = [], sessions = [], timetable = {}, note, preferences } = req.body;

    const idMap = {
      subjects: {},
      tasks: {}
    };

    let importedSubjects = 0;
    let importedTasks = 0;
    let importedSubtasks = 0;
    let importedSessions = 0;
    let importedTimetable = 0;

    // 1. Migrate Subjects
    for (const s of subjects) {
      if (!s.name) continue;
      const { data: newSubj, error: sErr } = await req.db
        .from('subjects')
        .insert({
          user_id: req.userId,
          name: s.name.trim(),
          code: s.code || '',
          color: s.color || '#6F8F72',
          teacher: s.teacher || '',
          semester: s.sem || '',
          target_grade: s.target || '',
          notes: s.notes || '',
          is_archived: !!s.arch
        })
        .select('id')
        .single();

      if (!sErr && newSubj) {
        idMap.subjects[s.id] = newSubj.id;
        importedSubjects++;
      }
    }

    // 2. Migrate Tasks
    for (const t of tasks) {
      if (!t.title) continue;
      const targetSubjectId = idMap.subjects[t.subj] || null;

      let validDue;
      try {
        const d = new Date(t.due);
        validDue = isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
      } catch {
        validDue = new Date().toISOString();
      }

      const { data: newTask, error: tErr } = await req.db
        .from('tasks')
        .insert({
          user_id: req.userId,
          subject_id: targetSubjectId,
          title: t.title.trim(),
          description: t.desc || '',
          category: ['Assignment', 'Exam', 'Lecture', 'Study', 'Reminder'].includes(t.cat) ? t.cat : 'Assignment',
          due_date: validDue,
          priority: ['Low', 'Medium', 'High', 'Urgent'].includes(t.pri) ? t.pri : 'Medium',
          status: ['To Do', 'In Progress', 'Completed'].includes(t.status) ? t.status : 'To Do',
          estimated_minutes: parseInt(t.est, 10) || 60,
          notes: t.notes || '',
          done_at: t.doneAt ? new Date(t.doneAt).toISOString() : null
        })
        .select('id')
        .single();

      if (!tErr && newTask) {
        idMap.tasks[t.id] = newTask.id;
        importedTasks++;

        // Migrate Subtasks
        if (Array.isArray(t.subs) && t.subs.length > 0) {
          const subPayload = t.subs
            .filter(sub => sub && (sub.t || sub.title))
            .map((sub, idx) => ({
              task_id: newTask.id,
              user_id: req.userId,
              title: (sub.t || sub.title).trim(),
              is_completed: !!(sub.d || sub.is_completed),
              position: idx
            }));

          if (subPayload.length > 0) {
            await req.db.from('subtasks').insert(subPayload);
            importedSubtasks += subPayload.length;
          }
        }
      }
    }

    // 3. Migrate Sessions
    for (const s of sessions) {
      const targetTaskId = idMap.tasks[s.task] || null;
      let sessionDate = new Date();
      if (s.at) {
        const d = new Date(s.at);
        if (!isNaN(d.getTime())) sessionDate = d;
      }

      const { error: sessErr } = await req.db
        .from('study_sessions')
        .insert({
          user_id: req.userId,
          task_id: targetTaskId,
          duration_minutes: parseInt(s.mins, 10) || 25,
          session_type: 'focus',
          started_at: sessionDate.toISOString(),
          created_at: sessionDate.toISOString()
        });

      if (!sessErr) importedSessions++;
    }

    // 4. Migrate Timetable
    if (timetable && typeof timetable === 'object') {
      const ttRows = [];
      for (const [key, content] of Object.entries(timetable)) {
        if (!content || !content.trim()) continue;
        const [rStr, cStr] = key.split('_');
        const r = parseInt(rStr, 10);
        const c = parseInt(cStr, 10);
        if (r >= 0 && r <= 8 && c >= 0 && c <= 5) {
          ttRows.push({
            user_id: req.userId,
            slot_row: r,
            day_col: c,
            content: content.trim()
          });
        }
      }

      if (ttRows.length > 0) {
        await req.db
          .from('timetable_entries')
          .upsert(ttRows, { onConflict: 'user_id,slot_row,day_col' });
        importedTimetable = ttRows.length;
      }
    }

    // 5. Migrate Note
    if (note && (note.title || note.body)) {
      await req.db
        .from('notes')
        .insert({
          user_id: req.userId,
          title: note.title || 'Quick note',
          body: note.body || ''
        });
    }

    // 6. Migrate Preferences
    if (preferences && typeof preferences === 'object') {
      await req.db
        .from('user_preferences')
        .upsert({
          user_id: req.userId,
          focus_minutes: preferences.foc || 25,
          short_break_minutes: preferences.sb || 5,
          long_break_minutes: preferences.lb || 15,
          weekly_target_hours: preferences.weekly || 10,
          auto_start_breaks: preferences.auto !== undefined ? !!preferences.auto : true,
          reduce_motion: !!preferences.rm
        });
    }

    res.json({
      success: true,
      message: 'Local browser data successfully migrated to your cloud database account.',
      summary: {
        subjects_imported: importedSubjects,
        tasks_imported: importedTasks,
        subtasks_imported: importedSubtasks,
        sessions_imported: importedSessions,
        timetable_slots_imported: importedTimetable
      }
    });
  } catch (err) {
    next(err);
  }
};
