import { supabaseAdmin } from '../config/supabase.js';
import { calculateXP, calculateStreaks } from '../services/statsService.js';

export const getProfile = async (req, res, next) => {
  try {
    // 1. Fetch profile
    const { data: profile, error: profError } = await req.db
      .from('profiles')
      .select('*')
      .eq('id', req.userId)
      .maybeSingle();

    if (profError) throw profError;

    // 2. Fetch user's tasks for real statistics
    const { data: tasks, error: tasksError } = await req.db
      .from('tasks')
      .select('id, status, due_date, done_at')
      .eq('user_id', req.userId);

    if (tasksError) throw tasksError;

    // 3. Fetch study sessions
    const { data: sessions, error: sessError } = await req.db
      .from('study_sessions')
      .select('id, duration_minutes, created_at, started_at')
      .eq('user_id', req.userId);

    if (sessError) throw sessError;

    // 4. Fetch subjects count
    const { count: subjectsCount, error: subjError } = await req.db
      .from('subjects')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', req.userId);

    if (subjError) throw subjError;

    // 5. Fetch achievements count
    const { count: achievementsCount, error: achError } = await req.db
      .from('user_achievements')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', req.userId);

    if (achError) throw achError;

    // 6. Fetch user preferences (for weekly target)
    const { data: prefs } = await req.db
      .from('user_preferences')
      .select('weekly_target_hours')
      .eq('user_id', req.userId)
      .maybeSingle();

    const now = new Date();
    const allTasks = tasks || [];
    const allSessions = sessions || [];

    const completedTasks = allTasks.filter(t => t.status === 'Completed');
    const pendingTasks = allTasks.filter(t => t.status !== 'Completed');
    const overdueTasks = pendingTasks.filter(t => new Date(t.due_date) < now);

    const totalFocusMinutes = allSessions.reduce((acc, s) => acc + (s.duration_minutes || 0), 0);
    const totalStudyHours = parseFloat((totalFocusMinutes / 60).toFixed(1));

    // Weekly study hours (last 7 days)
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weeklyMinutes = allSessions
      .filter(s => new Date(s.created_at || s.started_at) >= sevenDaysAgo)
      .reduce((acc, s) => acc + (s.duration_minutes || 0), 0);
    const weeklyHours = parseFloat((weeklyMinutes / 60).toFixed(1));
    const weeklyTarget = prefs?.weekly_target_hours ? parseFloat(prefs.weekly_target_hours) : 10.0;
    const weeklyProductivity = Math.min(100, Math.round((weeklyHours / weeklyTarget) * 100));

    // Streaks
    const streakInfo = calculateStreaks(allSessions, completedTasks, profile?.timezone || 'UTC');

    // XP and Level
    const xpInfo = calculateXP({
      completedTasksCount: completedTasks.length,
      focusMinutes: totalFocusMinutes,
      subjectsCount: subjectsCount || 0,
      achievementsCount: achievementsCount || 0
    });

    const emailConfirmed = !!req.user.email_confirmed_at;

    res.json({
      success: true,
      data: {
        profile: {
          id: req.user.id,
          email: req.user.email,
          email_confirmed: emailConfirmed,
          full_name: profile?.full_name || req.user.user_metadata?.full_name || '',
          username: profile?.username || '',
          avatar_url: profile?.avatar_url || req.user.user_metadata?.avatar_url || '',
          bio: profile?.bio || '',
          phone: profile?.phone || '',
          college: profile?.college || '',
          course: profile?.course || '',
          department: profile?.department || '',
          semester: profile?.semester || '',
          academic_year: profile?.academic_year || '',
          timezone: profile?.timezone || 'UTC',
          study_goal: profile?.study_goal || '',
          created_at: profile?.created_at || req.user.created_at,
          updated_at: profile?.updated_at || req.user.created_at
        },
        stats: {
          total_tasks: allTasks.length,
          completed_tasks: completedTasks.length,
          pending_tasks: pendingTasks.length,
          overdue_tasks: overdueTasks.length,
          total_study_hours: totalStudyHours,
          weekly_study_hours: weeklyHours,
          weekly_target_hours: weeklyTarget,
          weekly_productivity: weeklyProductivity,
          current_streak: streakInfo.currentStreak,
          longest_streak: streakInfo.longestStreak,
          total_xp: xpInfo.totalXP,
          level: xpInfo.level,
          next_level_xp: xpInfo.nextLevelXP,
          level_progress: xpInfo.progressPercent,
          achievements_count: achievementsCount || 0
        }
      }
    });
  } catch (err) {
    next(err);
  }
};

export const updateProfile = async (req, res, next) => {
  try {
    const updates = req.body;

    const { data: updated, error } = await req.db
      .from('profiles')
      .update(updates)
      .eq('id', req.userId)
      .select()
      .single();

    if (error) throw error;

    res.json({
      success: true,
      message: 'Profile updated successfully.',
      data: updated
    });
  } catch (err) {
    next(err);
  }
};

export const getPreferences = async (req, res, next) => {
  try {
    const { data, error } = await req.db
      .from('user_preferences')
      .select('*')
      .eq('user_id', req.userId)
      .maybeSingle();

    if (error) throw error;

    res.json({
      success: true,
      data: data || {
        user_id: req.userId,
        theme_palette: 0,
        theme_mode: 'light',
        focus_minutes: 25,
        short_break_minutes: 5,
        long_break_minutes: 15,
        weekly_target_hours: 10.0,
        auto_start_breaks: true,
        reduce_motion: false
      }
    });
  } catch (err) {
    next(err);
  }
};

export const updatePreferences = async (req, res, next) => {
  try {
    const updates = req.body;

    const { data, error } = await req.db
      .from('user_preferences')
      .upsert({
        user_id: req.userId,
        ...updates
      })
      .select()
      .single();

    if (error) throw error;

    res.json({
      success: true,
      message: 'Preferences updated successfully.',
      data
    });
  } catch (err) {
    next(err);
  }
};

export const deleteAccount = async (req, res, next) => {
  try {
    const confirm = req.body.confirmText;
    if (confirm !== 'DELETE') {
      return res.status(400).json({
        success: false,
        error: 'Account deletion requires explicit confirmation. Please provide confirmText: "DELETE".'
      });
    }

    // Delete user from auth via Supabase Admin
    if (supabaseAdmin) {
      const { error: adminError } = await supabaseAdmin.auth.admin.deleteUser(req.userId);
      if (adminError) throw adminError;
    } else {
      // Fallback: Delete from public profiles (triggers cascade on all user data)
      const { error: delError } = await req.db
        .from('profiles')
        .delete()
        .eq('id', req.userId);
      if (delError) throw delError;
    }

    res.json({
      success: true,
      message: 'Your account and all associated academic records have been permanently deleted.'
    });
  } catch (err) {
    next(err);
  }
};
