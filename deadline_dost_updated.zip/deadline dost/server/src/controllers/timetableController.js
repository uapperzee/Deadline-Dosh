export const getTimetable = async (req, res, next) => {
  try {
    const { data: entries, error } = await req.db
      .from('timetable_entries')
      .select('*')
      .eq('user_id', req.userId);

    if (error) throw error;

    // Convert to slot map key: "row_col" -> content
    const map = {};
    (entries || []).forEach(e => {
      map[`${e.slot_row}_${e.day_col}`] = e.content;
    });

    res.json({
      success: true,
      data: {
        entries: entries || [],
        map
      }
    });
  } catch (err) {
    next(err);
  }
};

export const updateSlot = async (req, res, next) => {
  try {
    const { slot_row, day_col, content } = req.body;

    if (slot_row === undefined || day_col === undefined) {
      return res.status(400).json({ success: false, error: 'slot_row and day_col are required.' });
    }

    const { data, error } = await req.db
      .from('timetable_entries')
      .upsert({
        user_id: req.userId,
        slot_row,
        day_col,
        content: content || ''
      }, { onConflict: 'user_id,slot_row,day_col' })
      .select()
      .single();

    if (error) throw error;

    res.json({
      success: true,
      data
    });
  } catch (err) {
    next(err);
  }
};

export const bulkUpdateTimetable = async (req, res, next) => {
  try {
    const { entries } = req.body;

    const payload = entries.map(e => ({
      user_id: req.userId,
      slot_row: e.slot_row,
      day_col: e.day_col,
      content: e.content || ''
    }));

    const { data, error } = await req.db
      .from('timetable_entries')
      .upsert(payload, { onConflict: 'user_id,slot_row,day_col' })
      .select();

    if (error) throw error;

    res.json({
      success: true,
      message: 'Timetable updated successfully.',
      data
    });
  } catch (err) {
    next(err);
  }
};

export const clearTimetable = async (req, res, next) => {
  try {
    const { error } = await req.db
      .from('timetable_entries')
      .delete()
      .eq('user_id', req.userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Timetable cleared successfully.'
    });
  } catch (err) {
    next(err);
  }
};
