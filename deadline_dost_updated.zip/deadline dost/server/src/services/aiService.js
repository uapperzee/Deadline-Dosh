import { config } from '../config/env.js';

/**
 * AIService handles generating contextual study recommendations,
 * exam preparation plans, deadline risk analysis, and interactive chat.
 */
export class AIService {
  /**
   * Generates a conversational AI response using configured LLM provider or contextual intelligence.
   */
  static async generateChatResponse({ prompt, studentContext, chatHistory = [] }) {
    const systemPrompt = `You are the AI Study Assistant for Deadline Dost, an elite student productivity platform.
Your mission is to help the student organize deadlines, overcome academic procrastination, study effectively, and balance their schedule.
Always speak warmly, encouragingly, concisely, and practically.
Use bullet points and clear formatting where helpful.

STUDENT ACADEMIC CONTEXT:
- Student Name: ${studentContext.name || 'Student'}
- Course / Semester: ${studentContext.course || 'Not specified'} ${studentContext.semester || ''}
- Study Goal: ${studentContext.studyGoal || 'Excel in academics with balance'}
- Active Tasks (${studentContext.activeTasks?.length || 0}):
${studentContext.activeTasks?.map(t => `  * [${t.priority}] "${t.title}" (${t.category}) - Due: ${t.due_date} - Subject: ${t.subject_name || 'General'}`).slice(0, 10).join('\n') || '  None currently open.'}
- Overdue Tasks: ${studentContext.overdueTasks?.map(t => `"${t.title}" (Due: ${t.due_date})`).join(', ') || 'None! Excellent job.'}
- Upcoming Exams: ${studentContext.upcomingExams?.map(t => `"${t.title}" on ${t.due_date}`).join(', ') || 'No exams registered yet.'}
- Subjects Registered: ${studentContext.subjects?.map(s => `${s.name} (${s.code || ''})`).join(', ') || 'None yet.'}
- Current Streak: ${studentContext.streak || 0} days
- Total Study Hours: ${studentContext.totalStudyHours || 0} hrs
`;

    // Check if AI API Key is provided
    if (config.ai.apiKey && config.ai.apiKey !== 'your-gemini-or-openai-api-key-here') {
      try {
        if (config.ai.provider === 'gemini') {
          return await this.callGeminiAPI(systemPrompt, prompt, chatHistory);
        } else if (config.ai.provider === 'openai' || config.ai.provider === 'groq') {
          return await this.callOpenAICompatibleAPI(systemPrompt, prompt, chatHistory);
        }
      } catch (err) {
        console.error('[AIService] Provider call failed:', err.message);
        // Fall back gracefully to contextual study coach
        return this.generateContextualFallback(prompt, studentContext, true);
      }
    }

    // If no external API key is configured, return the built-in intelligent contextual response
    return this.generateContextualFallback(prompt, studentContext, false);
  }

  /**
   * Calls Google Gemini API
   */
  static async callGeminiAPI(systemPrompt, userPrompt, chatHistory) {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${config.ai.model}:generateContent?key=${config.ai.apiKey}`;

    const contents = [
      {
        role: 'user',
        parts: [{ text: systemPrompt }]
      },
      {
        role: 'model',
        parts: [{ text: 'Understood. I have reviewed the student\'s active academic workload, deadlines, and schedule. How can I assist you today?' }]
      }
    ];

    // Append last 6 turns of chat history
    chatHistory.slice(-6).forEach(msg => {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      });
    });

    contents.push({
      role: 'user',
      parts: [{ text: userPrompt }]
    });

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1000
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    const candidate = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!candidate) throw new Error('No content returned from Gemini.');
    return candidate;
  }

  /**
   * Calls OpenAI/Groq compatible endpoint
   */
  static async callOpenAICompatibleAPI(systemPrompt, userPrompt, chatHistory) {
    const baseUrl = config.ai.provider === 'groq' 
      ? 'https://api.groq.com/openai/v1/chat/completions' 
      : 'https://api.openai.com/v1/chat/completions';

    const messages = [
      { role: 'system', content: systemPrompt },
      ...chatHistory.slice(-6).map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: userPrompt }
    ];

    const response = await fetch(baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.ai.apiKey}`
      },
      body: JSON.stringify({
        model: config.ai.model || (config.ai.provider === 'groq' ? 'llama-3.1-70b-versatile' : 'gpt-4o-mini'),
        messages,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`LLM provider error (${response.status}): ${errorText}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content || 'No response generated.';
  }

  /**
   * Built-in academic guidance engine when AI_API_KEY is not yet supplied or during network fallback.
   */
  static generateContextualFallback(prompt, ctx, hadProviderError = false) {
    const p = prompt.toLowerCase();
    const notice = hadProviderError 
      ? '> *Note: Upstream AI provider returned an error; here is your contextual workload breakdown.*' 
      : '> *💡 Note: To enable generative AI, set `AI_API_KEY` in `server/.env` (Google Gemini or OpenAI). Operating in smart local advisor mode.*';

    if (p.includes('due') || p.includes('deadline') || p.includes('today') || p.includes('tomorrow')) {
      const urgentTasks = ctx.activeTasks?.filter(t => t.priority === 'Urgent' || t.priority === 'High') || [];
      const overdue = ctx.overdueTasks || [];

      let reply = `${notice}\n\n### 📅 Deadline Briefing for ${ctx.name || 'You'}:\n`;
      if (overdue.length > 0) {
        reply += `⚠️ **Overdue Work Alert (${overdue.length} items):**\n` + overdue.map(t => `- **${t.title}** (Was due: ${new Date(t.due_date).toLocaleDateString()})`).join('\n') + `\n\n*Recommendation: Clear the oldest overdue item first in a 25-minute Pomodoro session.*`;
      } else {
        reply += `✨ **Zero overdue tasks!** You are in great shape.\n\n`;
      }

      if (urgentTasks.length > 0) {
        reply += `🔥 **High & Urgent Deadlines:**\n` + urgentTasks.map(t => `- **${t.title}** [${t.priority}] — due ${new Date(t.due_date).toLocaleString()}`).join('\n');
      } else {
        reply += `✅ No immediate urgent emergencies. You have ${ctx.activeTasks?.length || 0} active task(s) on your radar.`;
      }
      return reply;
    }

    if (p.includes('plan') || p.includes('exam') || p.includes('prep') || p.includes('schedule')) {
      return `${notice}\n\n### 🎯 Personalized Exam & Study Strategy:
1. **Focus on Spaced Repetition**: Break your subjects into 45-minute active recall blocks.
2. **Current Focus**: ${ctx.upcomingExams?.length ? `Your next upcoming exam is **${ctx.upcomingExams[0].title}**. Schedule at least 2 focus blocks daily.` : 'No upcoming exams detected. Go to **Study Planner** to generate an automated review schedule.'}
3. **Weekly Goal**: Your target is ${ctx.weeklyTarget || 10} hours. You have logged ${ctx.totalStudyHours || 0} hours so far.`;
    }

    if (p.includes('pomodoro') || p.includes('focus') || p.includes('timer') || p.includes('distract')) {
      return `${notice}\n\n### ⏱️ Focus Room Recommendations:
- **Active Rule**: 25 minutes single-task focus, 5 minutes screen-free break.
- **Task to Tackle Right Now**: ${ctx.activeTasks?.[0] ? `"${ctx.activeTasks[0].title}"` : 'Pick your toughest subject topic'}.
- Put your smartphone in another room or turn on 'Do Not Disturb'.`;
    }

    if (p.includes('quiz') || p.includes('test me')) {
      return `${notice}\n\n### 📝 Quick Knowledge Check Method:
1. Pick a topic from ${ctx.subjects?.[0]?.name || 'your notes'}.
2. Close your notes completely and write down the 5 core definitions or formulas from memory (Feynman Technique).
3. Open your notes and compare. Mark any gaps.`;
    }

    return `${notice}\n\nHello ${ctx.name || 'there'}! I am analyzing your **${ctx.activeTasks?.length || 0} active tasks** and **${ctx.subjects?.length || 0} registered subjects**.
You can ask me:
- *"What are my highest priority deadlines this week?"*
- *"Help me create a 5-day study plan for exams"*
- *"How can I catch up on my overdue assignments?"*
- *"Give me a study technique for ${ctx.subjects?.[0]?.name || 'difficult subjects'}"*`;
  }
}
