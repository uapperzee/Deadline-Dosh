/**
 * StatsService calculates verified student productivity metrics,
 * streaks, XP, levels, and badge eligibility from genuine database records.
 */

export const calculateXP = ({ completedTasksCount = 0, focusMinutes = 0, subjectsCount = 0, achievementsCount = 0 }) => {
  // 20 XP per completed task
  // 10 XP per 25-minute focus block
  // 50 XP per subject created
  // 100 XP per unlocked achievement
  const taskXP = completedTasksCount * 20;
  const focusXP = Math.floor(focusMinutes / 25) * 10;
  const subjectXP = subjectsCount * 50;
  const badgeXP = achievementsCount * 100;

  const totalXP = taskXP + focusXP + subjectXP + badgeXP;
  // Level curve: Level = floor(sqrt(totalXP / 50)) + 1
  const level = Math.floor(Math.sqrt(totalXP / 50)) + 1;
  const nextLevelXP = Math.pow(level, 2) * 50;
  const currentLevelBaseXP = Math.pow(level - 1, 2) * 50;
  const progressPercent = Math.min(100, Math.round(((totalXP - currentLevelBaseXP) / (nextLevelXP - currentLevelBaseXP || 1)) * 100));

  return {
    totalXP,
    level,
    nextLevelXP,
    progressPercent,
    breakdown: { taskXP, focusXP, subjectXP, badgeXP }
  };
};

/**
 * Calculates current streak and longest streak in consecutive active days.
 * An active day requires at least one finished focus session or a verified completed task.
 */
export const calculateStreaks = (sessions = [], completedTasks = [], userTimezone = 'UTC') => {
  const activeDaysSet = new Set();

  const getDateKey = (dateInput) => {
    try {
      const d = new Date(dateInput);
      if (isNaN(d.getTime())) return null;
      // Format as YYYY-MM-DD
      return d.toLocaleDateString('en-CA', { timeZone: userTimezone });
    } catch {
      return null;
    }
  };

  sessions.forEach(s => {
    if (s.created_at || s.started_at) {
      const k = getDateKey(s.created_at || s.started_at);
      if (k) activeDaysSet.add(k);
    }
  });

  completedTasks.forEach(t => {
    if (t.done_at) {
      const k = getDateKey(t.done_at);
      if (k) activeDaysSet.add(k);
    }
  });

  // Calculate current streak backward from today or yesterday
  const now = new Date();
  const todayKey = getDateKey(now);

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayKey = getDateKey(yesterday);

  let currentStreak = 0;
  let checkDate = new Date(now);

  // If active today, start counting from today. Otherwise, if active yesterday, count from yesterday.
  if (activeDaysSet.has(todayKey)) {
    checkDate = new Date(now);
  } else if (activeDaysSet.has(yesterdayKey)) {
    checkDate = yesterday;
  } else {
    // Neither today nor yesterday had activity -> current streak is 0
    currentStreak = 0;
  }

  if (activeDaysSet.has(getDateKey(checkDate))) {
    while (activeDaysSet.has(getDateKey(checkDate))) {
      currentStreak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }
  }

  // Calculate longest streak by sorting all active dates
  const sortedDates = Array.from(activeDaysSet).sort();
  let longestStreak = 0;
  let running = 0;
  let prevDate = null;

  for (const dateStr of sortedDates) {
    const curr = new Date(dateStr);
    if (!prevDate) {
      running = 1;
    } else {
      const diffMs = curr.getTime() - prevDate.getTime();
      const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        running++;
      } else if (diffDays > 1) {
        running = 1;
      }
    }
    prevDate = curr;
    if (running > longestStreak) longestStreak = running;
  }

  return {
    currentStreak,
    longestStreak: Math.max(longestStreak, currentStreak),
    totalActiveDays: activeDaysSet.size
  };
};

export const BADGE_DEFINITIONS = [
  { key: 'first_step', title: 'First step', description: 'Complete 1 task', goal: 1, type: 'tasks' },
  { key: 'task_master', title: 'Task master', description: 'Complete 10 tasks', goal: 10, type: 'tasks' },
  { key: 'deadline_hero', title: 'Deadline hero', description: 'Complete 25 tasks', goal: 25, type: 'tasks' },
  { key: 'on_a_roll', title: 'On a roll', description: 'Keep a 3 day streak', goal: 3, type: 'streak' },
  { key: 'unstoppable', title: 'Unstoppable', description: 'Keep a 7 day streak', goal: 7, type: 'streak' },
  { key: 'focused', title: 'Focused', description: 'Finish 5 focus sessions', goal: 5, type: 'sessions' },
  { key: 'deep_worker', title: 'Deep worker', description: 'Focus for 10 hours', goal: 10, type: 'focus_hours' },
  { key: 'organised', title: 'Organised', description: 'Add 3 subjects', goal: 3, type: 'subjects' },
  { key: 'timetable_builder', title: 'Timetable builder', description: 'Fill 10 timetable slots', goal: 10, type: 'timetable' }
];
