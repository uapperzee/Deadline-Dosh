import app from './app.js';
import { config } from './config/env.js';

const server = app.listen(config.port, () => {
  console.log(`=======================================================`);
  console.log(`🚀 Deadline Dost API Server running on port ${config.port}`);
  console.log(`📡 Environment: ${config.nodeEnv}`);
  console.log(`🌐 Allowed Client URL: ${config.clientUrl}`);
  console.log(`🔍 Health-check: http://localhost:${config.port}/api/health`);
  console.log(`=======================================================`);
});

// Graceful shutdown handling
const shutdown = () => {
  console.log('Shutting down Deadline Dost server gracefully...');
  server.close(() => {
    console.log('Server process terminated.');
    process.exit(0);
  });

  setTimeout(() => {
    console.error('Forced shutdown due to timeout.');
    process.exit(1);
  }, 10000);
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
