import { z } from 'zod';

export const taskCreateSchema = z.object({
  title: z.string().trim().min(1, 'Task title is required').max(120, 'Title cannot exceed 120 characters'),
  description: z.string().trim().max(1000).optional().default(''),
  subject_id: z.string().uuid().nullable().optional(),
  category: z.enum(['Assignment', 'Exam', 'Lecture', 'Study', 'Reminder'], {
    errorMap: () => ({ message: 'Invalid category. Choose Assignment, Exam, Lecture, Study, or Reminder.' })
  }),
  due_date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: 'Invalid due date format. Must be a valid ISO datetime.'
  }),
  priority: z.enum(['Low', 'Medium', 'High', 'Urgent'], {
    errorMap: () => ({ message: 'Priority must be Low, Medium, High, or Urgent.' })
  }).default('Medium'),
  status: z.enum(['To Do', 'In Progress', 'Completed'], {
    errorMap: () => ({ message: 'Status must be To Do, In Progress, or Completed.' })
  }).default('To Do'),
  estimated_minutes: z.coerce.number().int().min(5, 'Minimum estimate is 5 minutes').max(1440, 'Maximum estimate is 1440 minutes').default(60),
  notes: z.string().trim().max(2000).optional().default(''),
  subtasks: z.array(z.object({
    title: z.string().trim().min(1, 'Subtask title cannot be empty').max(120),
    is_completed: z.boolean().default(false),
    position: z.number().int().optional().default(0)
  })).optional().default([])
});

export const taskUpdateSchema = taskCreateSchema.partial().extend({
  done_at: z.string().nullable().optional()
});

export const subjectCreateSchema = z.object({
  name: z.string().trim().min(1, 'Subject name is required').max(60, 'Name cannot exceed 60 characters'),
  code: z.string().trim().max(30).optional().default(''),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Color must be a valid 6-character hex code (e.g. #6F8F72)').default('#6F8F72'),
  teacher: z.string().trim().max(60).optional().default(''),
  semester: z.string().trim().max(40).optional().default(''),
  target_grade: z.string().trim().max(20).optional().default(''),
  notes: z.string().trim().max(2000).optional().default('')
});

export const subjectUpdateSchema = subjectCreateSchema.partial().extend({
  is_archived: z.boolean().optional()
});

export const sessionCreateSchema = z.object({
  task_id: z.string().uuid().nullable().optional(),
  duration_minutes: z.coerce.number().int().min(1, 'Duration must be at least 1 minute').max(720, 'Duration cannot exceed 12 hours'),
  session_type: z.enum(['focus', 'short', 'long', 'stopwatch']).default('focus'),
  started_at: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: 'Invalid start date format.'
  }).optional()
});

export const profileUpdateSchema = z.object({
  full_name: z.string().trim().min(1, 'Full name cannot be empty').max(80).optional(),
  username: z.string().trim().min(3, 'Username must be at least 3 characters').max(30).regex(/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores').optional(),
  avatar_url: z.string().url().or(z.string().regex(/^\/?avatars\//)).nullable().optional(),
  bio: z.string().trim().max(500, 'Bio cannot exceed 500 characters').optional(),
  phone: z.string().trim().max(25).optional(),
  college: z.string().trim().max(100).optional(),
  course: z.string().trim().max(100).optional(),
  department: z.string().trim().max(100).optional(),
  semester: z.string().trim().max(40).optional(),
  academic_year: z.string().trim().max(40).optional(),
  timezone: z.string().trim().max(50).optional(),
  study_goal: z.string().trim().max(300).optional()
});

export const preferencesUpdateSchema = z.object({
  theme_palette: z.coerce.number().int().min(0).max(20).optional(),
  theme_mode: z.enum(['light', 'dark', 'system']).optional(),
  focus_minutes: z.coerce.number().int().min(1).max(120).optional(),
  short_break_minutes: z.coerce.number().int().min(1).max(60).optional(),
  long_break_minutes: z.coerce.number().int().min(1).max(90).optional(),
  weekly_target_hours: z.coerce.number().min(1).max(80).optional(),
  auto_start_breaks: z.boolean().optional(),
  reduce_motion: z.boolean().optional()
});

export const timetableBulkSchema = z.object({
  entries: z.array(z.object({
    slot_row: z.number().int().min(0).max(8),
    day_col: z.number().int().min(0).max(5),
    content: z.string().trim().max(60)
  }))
});

export const noteUpdateSchema = z.object({
  title: z.string().trim().max(100).default('Quick note'),
  body: z.string().default('')
});

export const aiPromptSchema = z.object({
  prompt: z.string().trim().min(1, 'Prompt cannot be empty').max(1000, 'Prompt too long')
});

export const localMigrationSchema = z.object({
  tasks: z.array(z.any()).optional().default([]),
  subjects: z.array(z.any()).optional().default([]),
  sessions: z.array(z.any()).optional().default([]),
  timetable: z.record(z.string()).optional().default({}),
  note: z.object({
    title: z.string().optional(),
    body: z.string().optional()
  }).optional(),
  preferences: z.record(z.any()).optional()
});
