import { createClient } from '@supabase/supabase-js';
import { config } from './env.js';

let supabaseAdmin = null;

if (config.supabase.url && config.supabase.serviceRoleKey) {
  supabaseAdmin = createClient(config.supabase.url, config.supabase.serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  });
} else {
  console.warn('[Deadline Dost Server] Warning: SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is not set. Cloud database calls will require valid environment variables.');
}

/**
 * Returns a Supabase client scoped to the authenticated user's JWT.
 * This ensures that Row Level Security (RLS) is applied consistently.
 * @param {string} token - The Bearer JWT from the user's request.
 */
export const getScopedClient = (token) => {
  if (!config.supabase.url) {
    throw new Error('Supabase URL is not configured on the server.');
  }

  return createClient(config.supabase.url, config.supabase.anonKey || config.supabase.serviceRoleKey, {
    global: {
      headers: {
        Authorization: `Bearer ${token}`
      }
    },
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  });
};

export { supabaseAdmin };
