import test from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../src/app.js';
import { calculateXP, calculateStreaks, BADGE_DEFINITIONS } from '../src/services/statsService.js';
import {
  taskCreateSchema,
  subjectCreateSchema,
  sessionCreateSchema,
  profileUpdateSchema
} from '../src/validators/schemas.js';

test('Health check endpoint returns 200, healthy status, and platform metadata', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'healthy');
  assert.equal(res.body.platform, 'Deadline Dost API');
  assert.equal(res.body.version, '1.0.0');
  assert.ok(typeof res.body.uptime === 'number');
  assert.ok(res.body.services);
});

test('Unauthenticated request to /api/tasks returns 401 Unauthorized', async () => {
  const res = await request(app).get('/api/tasks');
  assert.equal(res.status, 401);
  assert.equal(res.body.success, false);
  assert.match(res.body.error, /Authentication required/i);
});

test('Unauthenticated request to /api/profile returns 401 Unauthorized', async () => {
  const res = await request(app).get('/api/profile');
  assert.equal(res.status, 401);
  assert.equal(res.body.success, false);
});

test('Unauthenticated request to /api/subjects returns 401 Unauthorized', async () => {
  const res = await request(app).get('/api/subjects');
  assert.equal(res.status, 401);
  assert.equal(res.body.success, false);
});

test('Unauthenticated request to /api/ai/chat returns 401 Unauthorized', async () => {
  const res = await request(app).post('/api/ai/chat').send({ prompt: 'Hello' });
  assert.equal(res.status, 401);
  assert.equal(res.body.success, false);
});

test('Unauthenticated request to /api/export returns 401 Unauthorized', async () => {
  const res = await request(app).get('/api/export');
  assert.equal(res.status, 401);
  assert.equal(res.body.success, false);
});

test('Non-existent endpoint returns 404 Not Found JSON response', async () => {
  const res = await request(app).get('/api/random-unknown-route');
  assert.equal(res.status, 404);
  assert.equal(res.body.success, false);
  assert.match(res.body.error, /Resource not found/i);
});

test('taskCreateSchema validation accepts valid task and rejects missing required fields', () => {
  const validTask = {
    title: 'Complete Math Problem Set',
    category: 'Assignment',
    due_date: '2026-11-10T17:00:00Z',
    priority: 'High',
    status: 'To Do',
    estimated_minutes: 90,
    subtasks: [
      { title: 'Question 1', is_completed: false },
      { title: 'Question 2', is_completed: true }
    ]
  };
  const parsed = taskCreateSchema.safeParse(validTask);
  assert.ok(parsed.success);

  // Missing title
  const invalidTask = {
    category: 'Assignment',
    due_date: '2026-11-10T17:00:00Z'
  };
  const failed = taskCreateSchema.safeParse(invalidTask);
  assert.equal(failed.success, false);
});

test('subjectCreateSchema validation enforces color hex regex and name constraints', () => {
  const validSubject = {
    name: 'Operating Systems',
    code: 'CS302',
    color: '#5E8CA8',
    semester: 'Semester 4'
  };
  assert.ok(subjectCreateSchema.safeParse(validSubject).success);

  // Invalid hex color
  const invalidSubject = {
    name: 'Operating Systems',
    color: 'invalid-color-123'
  };
  assert.equal(subjectCreateSchema.safeParse(invalidSubject).success, false);
});

test('sessionCreateSchema validation enforces duration bounds', () => {
  assert.ok(sessionCreateSchema.safeParse({ duration_minutes: 25, session_type: 'focus' }).success);
  assert.equal(sessionCreateSchema.safeParse({ duration_minutes: 0 }).success, false);
  assert.equal(sessionCreateSchema.safeParse({ duration_minutes: 9999 }).success, false);
});

test('profileUpdateSchema validation restricts username characters', () => {
  assert.ok(profileUpdateSchema.safeParse({ full_name: 'Shreel Patel', username: 'shreel_01' }).success);
  // Usernames with spaces or illegal symbols are rejected
  assert.equal(profileUpdateSchema.safeParse({ username: 'shreel with spaces' }).success, false);
  assert.equal(profileUpdateSchema.safeParse({ username: 'shreel@test!' }).success, false);
});

test('calculateXP produces accurate XP, levels, and breakdown', () => {
  const xp0 = calculateXP({ completedTasksCount: 0, focusMinutes: 0 });
  assert.equal(xp0.totalXP, 0);
  assert.equal(xp0.level, 1);

  // 10 tasks (200 XP) + 50 mins focus (20 XP) + 1 subject (50 XP) + 1 badge (100 XP) = 370 XP
  const xp = calculateXP({
    completedTasksCount: 10,
    focusMinutes: 50,
    subjectsCount: 1,
    achievementsCount: 1
  });
  assert.equal(xp.totalXP, 370);
  assert.equal(xp.breakdown.taskXP, 200);
  assert.equal(xp.breakdown.focusXP, 20);
  assert.equal(xp.breakdown.subjectXP, 50);
  assert.equal(xp.breakdown.badgeXP, 100);
  assert.ok(xp.level >= 3);
});

test('calculateStreaks handles active sessions and completed tasks accurately', () => {
  const now = new Date();
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);

  const sessions = [
    { created_at: now.toISOString(), duration_minutes: 25 },
    { created_at: yesterday.toISOString(), duration_minutes: 50 }
  ];

  const completedTasks = [
    { done_at: now.toISOString() }
  ];

  const streaks = calculateStreaks(sessions, completedTasks, 'UTC');
  assert.ok(streaks.currentStreak >= 2);
  assert.ok(streaks.longestStreak >= 2);
  assert.ok(streaks.totalActiveDays >= 2);
});

test('BADGE_DEFINITIONS includes all 9 required productivity badges', () => {
  assert.equal(BADGE_DEFINITIONS.length, 9);
  const keys = BADGE_DEFINITIONS.map(b => b.key);
  assert.ok(keys.includes('first_step'));
  assert.ok(keys.includes('task_master'));
  assert.ok(keys.includes('deadline_hero'));
  assert.ok(keys.includes('on_a_roll'));
  assert.ok(keys.includes('unstoppable'));
  assert.ok(keys.includes('focused'));
  assert.ok(keys.includes('deep_worker'));
  assert.ok(keys.includes('organised'));
  assert.ok(keys.includes('timetable_builder'));
});
